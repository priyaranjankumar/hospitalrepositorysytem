package com.ranjan.loops;
public class Main {
    public static void main(String[] args) {
        int value = 200;

        while (value < 100)
        {
            System.out.println(value);
            value =value * 2;
        }
    }
}