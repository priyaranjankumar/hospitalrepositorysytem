package com.ranjan.arrays;
public class Main {
    public static void main(String[] args) {
        int arr [] = new int[3];
        arr [0]= 1;
        arr [1]= 1;
        arr [2]= 1;
        int sum=0;
        for(int i=0;i<arr.length;i++){
            sum+=arr[i];
        }
        System.out.println(sum);
    }
}