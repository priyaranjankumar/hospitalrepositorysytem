public class pattern5 {
    public static void main(String[] args) {
        printPattern(Integer.parseInt(args[0]));
    }
    static void printPattern(int n){
        // run the number of rows
        for (int i=n;i>0;i--){
            //run the number of columns
            for(int j=i;j>0;j--) System.out.print(j);
            System.out.println();
        }
    }
}
