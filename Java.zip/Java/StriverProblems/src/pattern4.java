public class pattern4 {
    public static void main(String[] args) {
        printPattern(Integer.parseInt(args[0]));
    }
    static void printPattern(int n){
        // run the number of rows
        for (int i=1;i<=n;i++){
            //run the number of columns
            for(int j=1;j<=i;j++) System.out.print(i);
            System.out.println();
        }
    }
}
