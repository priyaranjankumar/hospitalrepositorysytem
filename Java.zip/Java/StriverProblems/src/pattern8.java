public class pattern8 {
    public static void main(String[] args) {
        printPattern(Integer.parseInt(args[0]));
    }
    static void printPattern(int n){
////     run the loops
        for(int o=0;o<n/2;o++){
            //handle spaces
            for( int p=0;p<n/2-o-1;p++) System.out.print(" ");
            //handle characters
            for(int q=0;q<o*2+1;q++) System.out.print("*");
            //handle spaces
            for( int r=0;r<n/2-o-1;r++) System.out.print(" ");
            System.out.println();
        }
        for(int m=n/2;m>=1;m--){
            //handle the spaces
            for( int i=m;i<n;i++) System.out.print(" ");
            //handle character
            for( int j=0;j<(m*2)-1;j++) System.out.print("*");
            //handle space
            for( int k=m;k<m;k++) System.out.print(" ");
            System.out.println();
        }

    }


}
