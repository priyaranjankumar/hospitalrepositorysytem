public class pattern6 {
    public static void main(String[] args) {
        printPattern(Integer.parseInt(args[0]));
    }
    static void printPattern(int n){
        // run the number of rows
        for (int m=0;m<n;m++){
        //handle spaces
        for (int i=0;i<n-m-1;i++) System.out.print(" ");
        //handle charters
        for (int j=0;j<(2*m)+1;j++) System.out.print("*");
        //handle spaces
        for (int k=0;k<m-1;k++) System.out.print(" ");
        System.out.println();
        }
    }

}
