public class pattern7 {
    public static void main(String[] args) {
        printPattern(Integer.parseInt(args[0]));
    }
    static void printPattern(int n){
//     run the loops
        for(int m=n;m>=1;m--){
            //handle the spaces
            for( int i=m;i<n;i++) System.out.print(" ");
            //handle character
            for( int j=0;j<(m*2)-1;j++) System.out.print("*");
            //handle space
            for( int k=m;k<m;k++) System.out.print(" ");
            System.out.println();


        }
    }


}
