public class Main {
    public static void main(String[] args) {
//        System.out.println("pattern1");
//        pattern1.printPattern(5);
//        System.out.println("pattern2");
//        pattern2.printPattern(5);
//        System.out.println("pattern3");
//        pattern3.printPattern(5);
//        System.out.println("pattern4");
//        pattern4.printPattern(5);
        System.out.println("pattern5");
        pattern5.printPattern(5);
        System.out.println("pattern6");
        pattern6.printPattern(10);
        System.out.println("pattern7");
        pattern7.printPattern(10);
        System.out.println("pattern8");
        pattern8.printPattern(10);

    }
}