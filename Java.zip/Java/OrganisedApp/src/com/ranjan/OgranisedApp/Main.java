package com.ranjan.OgranisedApp;
public class Main {
    public static void main(String[] args) {

     float firstFloat= 1.0f;
     double firstDouble=2.0d;
     long  firstLong=3;
     int   firstInt= 1;
     short firstShort=4 ;

    }
}