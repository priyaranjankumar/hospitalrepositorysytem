package com.bullaInc.letGetLocigical;

public class Main {
    public static void main(String[] args) {

        int Students=150;
        int rooms = 0;
        if ( rooms!=0 && Students/rooms > 30){

        System.out.println("Crowded");
        }

        System.out.println("**end of pgm**");
    }
}