package com.bullaInc.calcEngine;

public class Main {
    public static void main(String[] args) {
        double [] leftval= {10d,20d,20d,40};
        double [] rightval= {10d,20d,20d,40};
        double [] results= new double[rightval.length];
        char [] opCodes= {'a','s','m','d'};
        if (args.length < 1){
           System.out.println("No arguments provided");
            for (int i=0;i< opCodes.length;i++){
                results[i]=execute(opCodes[i],leftval[i],rightval[i]);
            }
            for (double value:results
            ) {
                System.out.println(value);

            }
        } else if (args.length==3) {
            handleCommandline(args);


        }
        else{
            System.out.println("Please provide right commandline ");

        }

    }

    private static void handleCommandline(String[] args) {
        char opCodes =args[0].charAt(0);
        double leftval =Double.parseDouble(args[1]);
        double rightval =Double.parseDouble(args[2]);
        double results;
        results =execute(opCodes,leftval,rightval);
        System.out.println(results);
            }

    static double execute(char opCode, double lval,double rval){
        double result;
        switch (opCode) {
            case 'a':
                result = lval + rval;
                break;
            case 's':
                result = lval - rval;
                break;
            case 'm':
                result = lval * rval;
                break;
            case 'd':
                result = rval != 0 ? lval / rval : 0.0d;
                break;
            default:
                result = 0.0d;
                break;
        }
        return result;
    }
}